# geospatial-salesman
 Solving salesman problem with geospatial data using genetic algorithm.
